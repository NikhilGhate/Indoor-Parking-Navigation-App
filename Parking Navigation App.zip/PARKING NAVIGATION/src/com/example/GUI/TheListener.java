package com.example.GUI;

public interface TheListener {
	public void somethingHappened();

	
}
