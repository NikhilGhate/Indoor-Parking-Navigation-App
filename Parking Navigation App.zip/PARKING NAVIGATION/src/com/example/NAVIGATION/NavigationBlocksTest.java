package com.example.NAVIGATION;

import junit.framework.TestCase;

public class NavigationBlocksTest extends TestCase {
	NavigationBlocks nb = new NavigationBlocks(0, 0);
	
}
