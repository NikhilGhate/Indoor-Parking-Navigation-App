package com.example.NAVIGATION;

public class RouteCellMapping {
	public int[][] getRouteByCell (int x1, int x2, int y1, int y2) {
		
		
		
		int a[][] = null;
		a[0][0] = 1;
		a[0][1] = 2;
		return a;
	}

}
